package com.example.lab1dipanshu;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.sql.*;
public class HelloController implements Initializable {
    public TextField iID;
    public TextField iEmployeename;
    public TextField iWorkinghours;
    public TextField iCompanyname;
    public Label welcomeText;
    @FXML
    private TableView<employees> tableView;
    @FXML
    private TableColumn<employees,Integer > ID;
    @FXML
    private TableColumn<employees, String> Employeename;
    @FXML
    private TableColumn<employees,Integer> Workinghours;
    @FXML
    private TableColumn<employees,String> Companyname;
    ObservableList<employees> list = FXCollections.observableArrayList();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ID.setCellValueFactory(new
                PropertyValueFactory<employees,Integer>("ID"));
        Employeename.setCellValueFactory(new
                PropertyValueFactory<employees,String>("Employeename"));
        Workinghours.setCellValueFactory(new
                PropertyValueFactory<employees,Integer>("Workinghours"));
        Companyname.setCellValueFactory(new
                PropertyValueFactory<employees,String>("Companyname"));
        tableView.setItems(list);
    }
    @FXML
    protected void onHelloButtonClick() {
        list.clear();
        tableView.setItems(list);
        populateTable();
    }
    public void populateTable() {
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/db_lab1";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM employees";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int ID = resultSet.getInt("ID");
                String Employeename = resultSet.getString("Employeename");
                int Workinghours = resultSet.getInt("Workinghours");
                String Companyname = resultSet.getString("Companyname");
                tableView.getItems().add(new employees(ID, Employeename, Workinghours, Companyname));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void LoadData(ActionEvent actionEvent) {
        String getid = iID.getText();
        String jdbcUrl = "jdbc:mysql://localhost:3306/db_lab1";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM employees WHERE `ID` ='"+getid+"'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int ID = resultSet.getInt("ID");
                String Employeename = resultSet.getString("Employeename");
                String Workinghours = resultSet.getString("Workinghours");
                String Companyname = resultSet.getString("Companyname");

                iEmployeename.setText(Employeename);
                iWorkinghours.setText(Workinghours);
                iCompanyname.setText(Companyname);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void DeleteData(ActionEvent actionEvent) {
        String getid = iID.getText();
        String jdbcUrl = "jdbc:mysql://localhost:3306/db_lab1";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM employees WHERE `ID`= '"+getid+"'";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void InsertData(ActionEvent actionEvent) {
        String getid = iID.getText();
        String getEmployeename = iEmployeename.getText();
        String getWorkinghours = iWorkinghours.getText();
        String getCompanyname = iCompanyname.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/db_lab1";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO `employees`(`Employeename`, `Workinghours`, `Companyname`) VALUES ('"+getEmployeename+"','"+getWorkinghours+"','"+getCompanyname+"')";

            Statement statement = connection.createStatement();
            statement.execute(query);


            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void Update(ActionEvent actionEvent) {
        String getid = iID.getText();
        String getEmployeename = iEmployeename.getText();
        String getWorkinghours = iWorkinghours.getText();
        String getCompanyname = iCompanyname.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/db_lab1";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "UPDATE `employees` SET `Employeename`='"+getEmployeename+"',`Workinghours`='"+getWorkinghours+"',`Companyname`='"+getCompanyname+"' WHERE `ID` = '"+getid+"' ";
            welcomeText.setText(query);
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
